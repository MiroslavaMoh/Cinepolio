import Button from "./Button"

function MovieCard({ title, image }) {
return (
    <div style={{ 
        border: "1px solid #ddd",
        padding: "16px",
        margin: "16px",
        borderRadius: "8px",
        maxWidth: "200px"
    }}>
    

        <img src={image} />
        <h3>{title}</h3>
        <Button text="Ver horarios" />
    </div>
)
}

export default MovieCard