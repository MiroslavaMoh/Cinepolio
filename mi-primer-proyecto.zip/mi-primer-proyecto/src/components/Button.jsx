function Button({ text }) {
    return (
    <button
    style={{
        padding: "10px 20px",
        backgroundColor: "#ffc107",
        border: "none",
        borderRadius: "6px",
        color: "#000",
        cursor: "pointer"
    }}
    >
        {text}</button>
    )
}

export default Button