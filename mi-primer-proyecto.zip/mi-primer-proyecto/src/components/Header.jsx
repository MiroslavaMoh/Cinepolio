function Header() {
    return <header style={{ padding:"20px", backgroundColor: "#0b5ed7", color: "#fff" }}>
        <h1>Cartelera</h1>
    </header>
}

export default Header